import { CreatBotUserDto } from "./bot.dto";
import botUser from "./bot.model";

class BotRepo {
  
  public async create(data: CreatBotUserDto): Promise<botUser> {
    return botUser.create({
      ...data,
    });
  }

  public getByChatId(chat_id):Promise<botUser>{

    return botUser.findOne({
      where: {
        chat_id: chat_id,
      },
    });
  }
}



export default BotRepo;
