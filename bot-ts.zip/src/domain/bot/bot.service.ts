import BotRepo from "./bot.repo";
import SendRequest from "./request.axios";


class BotService {

    public SendSms= new SendRequest()
    public repo = new BotRepo()

    public async sendMessageWithButton(messageObj, messageText, buttons){
        try {
            const keyboard = {
                keyboard: buttons,
                resize_keyboard: true,
                one_time_keyboard: true,
              };
    
              return this.SendSms.post("sendMessage", { 
                chat_id: messageObj.chat.id, 
                text: messageText,
                reply_markup: keyboard, 
            }); 
            
        } catch (error) {
            console.error("Error in sendMessage:", error);
            throw error;
            
        }
    }
    public async sendMessage(messageObj, messageText){
        try {
               
              return this.SendSms.post("sendMessage", { 
                chat_id: messageObj.chat.id, 
                text: messageText,
            }); 
            
        } catch (error) {
            console.error("Error in sendMessage:", error);
            throw error;
            
        }
    }
    public async ReplyToStart(messageObj){
        try {

              const chat_id = messageObj.chat.id
              const username = messageObj.chat.username 
              const first_name: string = messageObj.chat.first_name
              
              const NewData = {
                chat_id : chat_id,
                username: username,
                first_name: first_name
              }
              const checkUser = await this.repo.getByChatId(`${chat_id}`)
              console.log(checkUser);
              
              if (!checkUser) {
                await this.repo.create(NewData);
                return this.SendSms.post("sendMessage", { 
                    chat_id: messageObj.chat.id, 
                    text: `👋Salom ${first_name}! Sizga yordam berishdan mamnunmiz! telefon raqamingizni kiriting!`,
                    reply_markup: {
                    keyboard: [[{ text: "Jo'natish", request_contact: true }]],
                    resize_keyboard: true,
                    one_time_keyboard: true,
                },
              });
               
              } else {
                return this.SendSms.post("sendMessage", { 
                    chat_id: messageObj.chat.id, 
                    text: `👋Salom ${first_name}! Sizga yordam berishdan mamnunmiz! telefon raqamingizni kiriting!`,
                    reply_markup: {
                    keyboard: [[{ text: "Jo'natish", request_contact: true }]],
                    resize_keyboard: true,
                    one_time_keyboard: true,
                },
              }) 
              }
                          
        } catch (error) {
            console.error("Error in sendMessage:", error);
            throw error;
            
        }
    }

    public handleMessage(messageObj){
        const messageText = messageObj.text || ''; 
 
    if (messageText.charAt(0) == "/"){ 
 
        const command = messageText.substr(1); 
 
        switch (command) { 
            case "start":
                const buttons = [
                    [{ text: 'Button 1' }],
                    [{ text: 'Button 2' }],
                  ];
            return this.ReplyToStart(messageObj) 
            default: 
            return this.sendMessage(messageObj, "salom, afsuski men bu buyruqni bilmayman")    ; 
                 
        } 
 
    } else { 
        return this.sendMessage(messageObj, messageText); 
    } 
 

    }
    
  
}

export default BotService;