export interface IApplicantStatus {
    status: string;
    id?: string;
  }