export interface IPayloadUser {
    id: string;
    username: string;
    firstName: string;
}
