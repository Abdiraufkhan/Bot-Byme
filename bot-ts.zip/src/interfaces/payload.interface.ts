export interface IPayload {
    access_id: string;
    recipient: string;
}
export interface IPayloadUser {
    access_id: string;
    recipient: string;
}
