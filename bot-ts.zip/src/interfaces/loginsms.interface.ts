export interface Isms {
    recipient: string;
    smscode: string;
}
